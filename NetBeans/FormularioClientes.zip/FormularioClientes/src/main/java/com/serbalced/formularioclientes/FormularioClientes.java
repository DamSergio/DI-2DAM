/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.serbalced.formularioclientes;

/**
 *
 * @author Sergio
 */
public class FormularioClientes {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
